module AestheticsHelper
end
