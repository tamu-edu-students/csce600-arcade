class Settings < ApplicationRecord
  belongs_to :user
end
